
var monkey , monkey_running
var banana ,bananaImage, obstacle, obstacleImage
var FoodGroup, obstacleGroup
var score

function preload(){
  
  
monkey_running =            loadAnimation("sprite_0.png","sprite_1.png","sprite_2.png","sprite_3.png","sprite_4.png","sprite_5.png","sprite_6.png","sprite_7.png","sprite_8.png")
  
  bananaImage = loadImage("banana.png");
  obstacleImage = loadImage("obstacle.png");
 
}



function setup() {
  createCanvas (400,400)
  
  monkey = createSprite(120,300);
  monkey.addAnimation(monkey_running);
  monkey.scale = 0.3;
  
  
 banana = createSprite(200,200);
  banana.addImage(bananaImage);
  banana.scale = 0.2;
  
  obstacle  = createSprite(200,300);
  obstacle.addImage(obstacleImage);
  obstacle.scale = 0.2;
}


function draw() {
    background = (0);
  

  
  
  
  drawSprites();
  
}






